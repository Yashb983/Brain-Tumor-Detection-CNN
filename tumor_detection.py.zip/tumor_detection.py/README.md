# Brain Tumor Detection using Deep Learning (CNN)

This project is a medical image classification system that detects brain tumors from MRI images using Convolutional Neural Networks (CNN).

## Technologies Used
- Python
- TensorFlow
- OpenCV
- NumPy
- Matplotlib

## Project Description
The model is trained on MRI images of tumor and non-tumor cases. It learns image patterns and predicts whether a tumor is present in a new MRI scan.

## Features
- Image preprocessing
- CNN model training
- Tumor prediction
- Visualization of results

## Outcome
Achieved ~88% accuracy in detecting tumors.

## Future Improvements
- U-Net segmentation
- Web application deployment
- Real-time detection
