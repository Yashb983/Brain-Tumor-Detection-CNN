import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
import numpy as np
import matplotlib.pyplot as plt
import os
import cv2

data_dir = r"C:\Users\techc\OneDrive\Desktop\brain_tumor_dataset"

categories = ["yes","no"]
data = []

for category in categories:
    path = os.path.join(data_dir, category)
    label = categories.index(category)

    for img in os.listdir(path):
        img_path = os.path.join(path, img)
        image = cv2.imread(img_path)
        image = cv2.resize(image,(128,128))
        data.append([image,label])

X=[]
y=[]

for features,label in data:
    X.append(features)
    y.append(label)

X = np.array(X)/255.0
y = np.array(y)

model = Sequential()
model.add(Conv2D(32,(3,3),activation='relu',input_shape=(128,128,3)))
model.add(MaxPooling2D(2,2))

model.add(Conv2D(64,(3,3),activation='relu'))
model.add(MaxPooling2D(2,2))

model.add(Flatten())
model.add(Dense(128,activation='relu'))
model.add(Dense(1,activation='sigmoid'))

model.compile(optimizer='adam',loss='binary_crossentropy',metrics=['accuracy'])

model.fit(X,y,epochs=5)

print("Model trained successfully")


# ----------- PREDICTION PART --------------

import matplotlib.pyplot as plt

img_path = input("Enter MRI image path: ")

test_img = cv2.imread(img_path)
test_img = cv2.resize(test_img,(128,128))
test_img = test_img/255.0
test_img = test_img.reshape(1,128,128,3)

prediction = model.predict(test_img)

if prediction[0][0] > 0.5:
    result = "No Tumor"
else:
    result = "Tumor Detected"

print("Prediction:", result)

# show image
plt.imshow(cv2.cvtColor(cv2.imread(img_path), cv2.COLOR_BGR2RGB))
plt.title(result)
plt.axis("off")
plt.show()
